
import { GoogleGenAI, Type } from "@google/genai";
import { Locale, TestType, Question } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateTestQuestions = async (
  testType: TestType,
  description: string
): Promise<Question[]> => {
  const model = 'gemini-3-flash-preview';
  const prompt = `
    Generate 8 unique and psychologically insightful multiple-choice questions for a test about "${testType}".
    Context: ${description}.
    
    Each question must have exactly 5 options with weights ranging from 0 to 10.
    Weights should reflect the intensity or positivity of the answer (e.g., 10 for best, 0 for worst).
    
    CRITICAL: Provide text in BOTH Russian (RU) and English (EN) for every string.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              text: {
                type: Type.OBJECT,
                properties: {
                  RU: { type: Type.STRING },
                  EN: { type: Type.STRING }
                },
                required: ["RU", "EN"]
              },
              options: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    text: {
                      type: Type.OBJECT,
                      properties: {
                        RU: { type: Type.STRING },
                        EN: { type: Type.STRING }
                      },
                      required: ["RU", "EN"]
                    },
                    weight: { type: Type.NUMBER }
                  },
                  required: ["id", "text", "weight"]
                }
              }
            },
            required: ["id", "text", "options"]
          }
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Generation Error:", error);
    throw error;
  }
};

export const generateTestAnalysis = async (
  testType: TestType,
  answers: any[],
  locale: Locale
) => {
  const model = 'gemini-3-flash-preview';
  const prompt = `
    Analyze the following test results for a ${testType} test.
    The user provided these answers: ${JSON.stringify(answers)}.
    Provide a detailed and inspiring report in ${locale === 'RU' ? 'Russian' : 'English'}.
    Structure the response with:
    1. Overall Score Summary
    2. Strengths
    3. Areas for Improvement
    4. Practical Recommendations
    Format as Markdown.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        temperature: 0.7,
        topP: 0.9,
      }
    });
    return response.text || "Failed to generate report.";
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "Error generating AI analysis. Please try again later.";
  }
};

export const analyzeFoodImage = async (
  base64Image: string, 
  locale: Locale, 
  physicalProfile?: { weight?: number; height?: number; age?: number; gender?: string }
) => {
  const model = 'gemini-3-flash-preview';
  
  let userContext = "";
  if (physicalProfile && (physicalProfile.weight || physicalProfile.height || physicalProfile.age || physicalProfile.gender)) {
    userContext = `User Profile: ${physicalProfile.gender ? `Sex: ${physicalProfile.gender}, ` : ''}${physicalProfile.age ? `Age: ${physicalProfile.age}, ` : ''}${physicalProfile.height ? `Height: ${physicalProfile.height}cm, ` : ''}${physicalProfile.weight ? `Weight: ${physicalProfile.weight}kg.` : ''}`;
  }

  const prompt = `
    Analyze this food image. 
    ${userContext ? `CONTEXT: The user is analyzing this food for their personal diet. ${userContext}` : ''}
    1. Identify the dish or ingredients.
    2. Estimate total calories.
    3. Estimate proteins, fats, and carbohydrates in grams.
    4. Provide a brief health tip based on this food. ${userContext ? "Make the tip PERSONALIZED using the provided physical profile, considering biological sex and physical dimensions for metabolic accuracy." : ""}
    Return the response in ${locale === 'RU' ? 'Russian' : 'English'}.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: base64Image } },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            itemName: { type: Type.STRING },
            calories: { type: Type.NUMBER },
            macros: {
              type: Type.OBJECT,
              properties: {
                proteins: { type: Type.NUMBER },
                fats: { type: Type.NUMBER },
                carbs: { type: Type.NUMBER }
              },
              required: ["proteins", "fats", "carbs"]
            },
            healthTip: { type: Type.STRING }
          },
          required: ["itemName", "calories", "macros", "healthTip"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Food Analysis Error:", error);
    throw error;
  }
};
